local menuOpen = false

local function openPauseMenu()
    if not menuOpen then
        menuOpen = true
        SetNuiFocus(true, true)
        SendNUIMessage({type = 'show'})
    end
end

local function closePauseMenu()
    if menuOpen then
        menuOpen = false
        SetNuiFocus(false, false)
        SendNUIMessage({type = 'hide'})
    end
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if menuOpen then
            DisableControlAction(0, 200, true)
        end
    end
end)

lib.addKeybind({
    name = 'PauseMenu',
    description = 'Open Pause Menu',
    defaultKey = 'ESCAPE',
    onPressed = function()
        if menuOpen then
            closePauseMenu()
        else
            openPauseMenu()
        end
    end
})

RegisterNUICallback('resume', function(data, cb)
    closePauseMenu()
    cb({})
end)

RegisterNUICallback('map', function(data, cb)
    closePauseMenu()
    Citizen.CreateThread(function()
        ActivateFrontendMenu("FE_MENU_VERSION_MP_PAUSE", true, -1)
        while not IsPauseMenuActive() do Wait(0) end
        PauseMenuceptionGoDeeper(0)
        PauseMenuceptionTheKick()
    end)
    cb('ok')
end)


RegisterNUICallback('settings', function(data, cb)
    closePauseMenu()
    Citizen.CreateThread(function()
        ActivateFrontendMenu(GetHashKey('FE_MENU_VERSION_LANDING_MENU'), 0, -1)
        Citizen.Wait(100) 
        SetNuiFocus(false, false)
    end)
    cb('ok')
end)


RegisterNUICallback('disconnect', function(data, cb)
    closePauseMenu()
    TriggerServerEvent('Fekelele_pausamenu:disconnect')
    cb({})
end)

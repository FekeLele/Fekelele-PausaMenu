
lua54 'yes'
fx_version 'cerulean'
game 'gta5'

author 'Fekelele'
description 'Menu Pausa FiveM personalizzato stile GTA'
version '1.0.0'


shared_scripts {
    "@es_extended/imports.lua", 
    "@ox_lib/init.lua",
}


ui_page 'html/index.html'

files {
    'html/index.html',
    'html/script.js',
    'html/style.css',
    'html/*.png',
    'html/*.jpg',
    'html/*.jpeg'
}

client_scripts {
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}



dependencies {
    "es_extended",
    "ox_lib"
}


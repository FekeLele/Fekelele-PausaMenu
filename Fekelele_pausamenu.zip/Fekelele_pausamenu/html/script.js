
function resumeGame(event) {
    sendNuiCallback('resume');
}

function openMap(event) {
    sendNuiCallback('map');
}

function openSettings(event) {
    sendNuiCallback('settings');
}

function disconnectFromServer(event) {
    sendNuiCallback('disconnect');
}

// ESC per toggle menu pausa
let menuVisible = false;

function sendNuiCallback(name) {
    fetch(`https://${GetParentResourceName()}/${name}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
}

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        event.preventDefault();
        if (menuVisible) {
            document.body.style.display = 'none';
            menuVisible = false;
            sendNuiCallback('resume');
        } else {
            document.body.style.display = 'block';
            menuVisible = true;
        }
    }
});

window.addEventListener('message', function(event) {
    const data = event.data;
    if (data.type === 'show') {
        document.body.style.display = 'block';
        menuVisible = true;
    } else if (data.type === 'hide') {
        document.body.style.display = 'none';
        menuVisible = false;
    }
});

document.body.style.display = 'none';


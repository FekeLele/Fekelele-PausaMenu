RegisterNetEvent('Fekelele_pausamenu:disconnect')
AddEventHandler('Fekelele_pausamenu:disconnect', function()
    DropPlayer(source, 'Sei stato disconnesso dal menu pausa.')
end)
